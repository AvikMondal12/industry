// let arr=[1,2,3,4,5,6,7];
// for(let i of arr){
//     console.log(arr[i])
// }
// while(true){
//     console.log("hey");
// }