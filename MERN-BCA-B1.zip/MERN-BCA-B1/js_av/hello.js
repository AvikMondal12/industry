console.log("Hello world");
let a=5;
let b = 6;
console.log(a*b);