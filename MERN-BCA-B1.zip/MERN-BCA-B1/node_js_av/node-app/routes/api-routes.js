const express=require('express');
const router=express.Router();
const ApiController=require('../controller/api-controller');
router.get('/user/list',ApiController.getUser)
router.get('/user',function(req,res){
    res.send({
        "message":"Hello"
    })
});
module.exports={
    route:router
}