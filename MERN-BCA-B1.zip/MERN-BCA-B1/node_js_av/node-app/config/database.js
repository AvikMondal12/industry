const mongoose = require('mongoose');

module.exports=()=>{
    try{
        mongoose.connect(process.env.MONGODB_URL)

        console.log('mongodb connected successfully..')
    }
    catch(err){
        console.log('monodb connection error..',err)
    }
}