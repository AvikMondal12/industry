const userModel = require('../model/user-model');
const usermodel=require('../model/user-model')
class apiController{
    getUser = async (req,res) => {
let userData=await usermodel.find()
console.log(userData,'userData');
let singleuserData=await usermodel.findOne();
console.log(singleuserData,'singleuserData');


        res.send({
            // "message":"hello",
            // "email":"abc@gmail.com",
            data:userData
        })
    }
}
module.exports=new apiController();