// console.log("Hello node js ");
// setTimeout(() => {
//     console.log("Hello js");
// },500)
// console.log("Hello world")
// test();
// const test=function(){
//     console.log("Hello from server")
// }
// // test();
// (function(){
//     console.log("Hello from server")
// })();
// const http = require('http');

// http.createServer(function (req, res) {
//   res.writeHead(200, {'Content-Type': 'text/plain'});
//   res.end('Hello World!');
// }).listen(8080);

const http = require('http');
const path = require('path');
const dotenv = require('dotenv')
dotenv.config();
const express = require('express')
const app = express();
// const path= require('path')



require('./config/database')();
const router=require('./routes/api-routes');
const PORT = process.env.PORT;
app.use(express.static("public"));

app.get('/user', function (req, res) {
  res.send({
    "message": "Hello"
  })
})

app.use('/api',router.route);
app.use(express.static(path.join(__dirname,"public")))
let server = http.createServer(app);
server.listen(PORT, function (err) {
  if (err) throw err;
  console.log(`Server running on the port :${PORT}`);
})


