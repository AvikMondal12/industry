let name= {
    "avik":"bca",
    "suman":"btech",
    "manish":"mca",
    "kuntal":"mtech",
    "ayan":"bphram"
}
// console.log(name);
