const mongoose=require("mongoose")
const schema= mongoose.Schema;
const usermodel=new schema({
    name :
    {
        type:String
    },
    email :
    {
        type:String
    },
    phone :
    {
        type:String
    },
    age :
    {
        type:Number
    }
})
module.exports = mongoose.model('usert',usermodel);